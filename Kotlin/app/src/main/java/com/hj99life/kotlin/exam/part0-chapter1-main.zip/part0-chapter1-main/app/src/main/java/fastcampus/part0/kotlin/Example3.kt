package fastcampus.part0.kotlin

fun main() {
    // 3. 변수
    // val = value (값)
    // var = variable (변경가능한)
    val a : Int = 3
    var b : Int = 10
    b = 20

    val name = "채상아"

}