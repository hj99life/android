package fastcampus.part0.kotlin

fun main() {
    val a = 10
    val name = "안녕"
    val isHigh = true

    println("$a ${name.length} $isHigh")
}